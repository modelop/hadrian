# Copyright (C) 2014  Open Data ("Open Data" refers to
# one or more of the following companies: Open Data Partners LLC,
# Open Data Research LLC, or Open Data Capital LLC.)
# 
# This file is part of Hadrian.
# 
# Licensed under the Hadrian Personal Use and Evaluation License (PUEL);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://raw.githubusercontent.com/opendatagroup/hadrian/master/LICENSE
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

counter <- new.env()
counter$engine <- 0
counter$record <- 0
counter$enum <- 0
counter$fixed <- 0
counter$symbol <- 0

#' uniqueEngineName
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export uniqueEngineName
#' @examples
#' someExamples

uniqueEngineName <- function() {
    counter$engine <- counter$engine + 1
    paste("Engine_", counter$engine, sep = "")
}

#' uniqueRecordName
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export uniqueRecordName
#' @examples
#' someExamples

uniqueRecordName <- function() {
    counter$record <- counter$record + 1
    paste("Record_", counter$record, sep = "")
}

#' uniqueEnumName
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export uniqueEnumName
#' @examples
#' someExamples

uniqueEnumName <- function() {
    counter$enum <- counter$enum + 1
    paste("Enum_", counter$enum, sep = "")
}

#' uniqueFixedName
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export uniqueFixedName
#' @examples
#' someExamples

uniqueFixedName <- function() {
    counter$fixed <- counter$fixed + 1
    paste("Fixed_", counter$fixed, sep = "")
}
#' uniqueSymbolName
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export uniqueSymbolName
#' @examples
#' someExamples

uniqueSymbolName <- function(symbols) {
    while (TRUE) {
        counter$symbol <- counter$symbol + 1
        test <- paste("tmp_", counter$symbol, sep = "")
        if (!(test %in% ls(symbols)))
            return(test)
    }
}
