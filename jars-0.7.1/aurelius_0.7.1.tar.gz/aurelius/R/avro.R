# Copyright (C) 2014  Open Data ("Open Data" refers to
# one or more of the following companies: Open Data Partners LLC,
# Open Data Research LLC, or Open Data Capital LLC.)
# 
# This file is part of Hadrian.
# 
# Licensed under the Hadrian Personal Use and Evaluation License (PUEL);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://raw.githubusercontent.com/opendatagroup/hadrian/master/LICENSE
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#' avro.null
#'
#' describeme
#'
#' @export avro.null
#' @name avro.null

avro.null <- "null"

#' avro.boolean
#'
#' describeme
#'
#' @export avro.boolean
#' @name avro.boolean

avro.boolean <- "boolean"

#' avro.int
#'
#' describeme
#'
#' @export avro.int
#' @name avro.int

avro.int <- "int"

#' avro.long
#'
#' describeme
#'
#' @export avro.long
#' @name avro.long

avro.long <- "long"

#' avro.float
#'
#' describeme
#'
#' @export avro.float
#' @name avro.float

avro.float <- "float"

#' avro.double
#'
#' describeme
#'
#' @export avro.double
#' @name avro.double

avro.double <- "double"

#' avro.bytes
#'
#' describeme
#'
#' @export avro.bytes
#' @name avro.bytes

avro.bytes <- "bytes"

#' avro.fixed
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export avro.fixed
#' @examples
#' someExamples

avro.fixed <- function(size, name = NULL, namespace = NULL) {
    if (is.null(name))
        name <- uniqueFixedName()
    if (is.null(namespace))
        list(type = "fixed", size = size, name = name)
    else
        list(type = "fixed", size = size, name = name, namespace = namespace)
}

#' avro.string
#'
#' describeme
#'
#' @export avro.string
#' @name avro.string

avro.string <- "string"

#' avro.enum
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export avro.enum
#' @examples
#' someExamples

avro.enum <- function(symbols, name = NULL, namespace = NULL) {
    if (is.null(name))
        name <- uniqueEnumName()
    if (is.null(namespace))
        list(type = "enum", symbols = symbols, name = name)
    else
        list(type = "enum", symbols = symbols, name = name, namespace = namespace)
}

#' avro.array
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export avro.array
#' @examples
#' someExamples

avro.array <- function(items) {
    list(type = "array", items = items)
}

#' avro.map
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export avro.map
#' @examples
#' someExamples

avro.map <- function(values) {
    list(type = "map", values = values)
}

#' avro.record
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export avro.record
#' @examples
#' someExamples

avro.record <- function(fields, name = NULL, namespace = NULL) {
    outputFields <- list()
    for (x in names(fields))
        outputFields[[length(outputFields) + 1]] = list(name = x, type = fields[[x]])
    if (is.null(name))
        name <- uniqueRecordName()
    if (is.null(namespace))
        list(type = "record", fields = outputFields, name = name)
    else
        list(type = "record", fields = outputFields, name = name, namespace = namespace)
}

#' avro.union
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export avro.union
#' @examples
#' someExamples

avro.union <- function(...) list(...)
