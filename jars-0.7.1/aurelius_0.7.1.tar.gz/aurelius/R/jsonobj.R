# Copyright (C) 2014  Open Data ("Open Data" refers to
# one or more of the following companies: Open Data Partners LLC,
# Open Data Research LLC, or Open Data Capital LLC.)
# 
# This file is part of Hadrian.
# 
# Licensed under the Hadrian Personal Use and Evaluation License (PUEL);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
# 
#     http://raw.githubusercontent.com/opendatagroup/hadrian/master/LICENSE
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

#' json.map
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export json.map
#' @examples
#' someExamples

json.map <- function(...) {
    args <- list(...)
    if (length(args) == 0)
        setNames(list(), list())
    else if (is.null(names(args)))
        stop("json.map must have named parameters")
    else
        args
}

#' json.array
#'
#' describeme
#' @param x describeme
#' @return describeme
#' @export json.array
#' @examples
#' someExamples

json.array <- function(...) {
    args <- list(...)
    if (!is.null(names(args)))
        stop("json.array must not have named parameters")
    else
        args
}
